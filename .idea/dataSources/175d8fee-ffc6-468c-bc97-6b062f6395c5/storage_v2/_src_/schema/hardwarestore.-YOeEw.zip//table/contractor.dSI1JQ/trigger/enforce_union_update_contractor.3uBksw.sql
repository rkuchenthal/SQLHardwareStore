create definer = root@localhost trigger enforce_union_update_contractor
    before update
    on contractor
    for each row
BEGIN
        if old.cid <> new.cid
        then
            UPDATE customer
            SET cid = new.cid
            WHERE cid = old.cid;

        end if;
    END;

