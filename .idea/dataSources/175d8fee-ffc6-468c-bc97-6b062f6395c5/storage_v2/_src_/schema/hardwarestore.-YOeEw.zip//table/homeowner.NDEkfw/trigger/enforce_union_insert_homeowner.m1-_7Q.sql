create definer = root@localhost trigger enforce_union_insert_homeowner
    before insert
    on homeowner
    for each row
BEGIN
        if new.cid NOT IN  (
        SELECT cid
        FROM customer
         UNION
        SELECT cid
        FROM contractor
        )
        then signal sqlstate '45000'
          SET MESSAGE_TEXT = 'Must create cid in Customer table first, before entering homeOwner information';
        end if;
    END;

