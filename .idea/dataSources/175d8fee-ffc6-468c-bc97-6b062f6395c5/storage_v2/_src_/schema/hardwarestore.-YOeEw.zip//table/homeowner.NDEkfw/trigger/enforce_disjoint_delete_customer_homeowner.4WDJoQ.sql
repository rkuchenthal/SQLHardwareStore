create definer = root@localhost trigger enforce_disjoint_delete_customer_homeowner
    after delete
    on homeowner
    for each row
begin
      if old.cid in (
        SELECT cid
        FROM customer
        )
        then
          DELETE FROM customer
              WHERE old.cid = cid;
        end if;
    end;

