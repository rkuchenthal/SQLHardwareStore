create definer = root@localhost trigger enforce_union_insert_contractor
    before insert
    on contractor
    for each row
BEGIN
        if new.cid NOT IN  (
        SELECT cid
        FROM customer
         UNION
        SELECT cid
        FROM homeowner
        )
        then signal sqlstate '45000'
          SET MESSAGE_TEXT = 'Must create cid in Customer table first, before entering contractor information';
        end if;
    END;

