create definer = root@localhost trigger enforce_disjoint_update_hardware
    before update
    on hardware
    for each row
begin
      if new.sku in (
        SELECT sku
        FROM Plant
        )
        then signal sqlstate '45000'
          SET MESSAGE_TEXT = 'Subclasses must be disjoint, sku already exists in Plant';
        end if;
    end;

