create definer = root@localhost trigger enforce_disjoint_update_plant
    before update
    on plant
    for each row
begin
      if new.sku in (
        SELECT sku
        FROM Hardware
        )
        then signal sqlstate '45000'
          SET MESSAGE_TEXT = 'Subclasses must be disjoint, sku already exists in Hardware';
        end if;
    end;

